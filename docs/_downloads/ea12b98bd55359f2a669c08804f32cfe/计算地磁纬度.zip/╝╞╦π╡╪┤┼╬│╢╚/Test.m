clear;clc;
% 加载数据
p1='E:\008---Paper\003---Data\COSMIC\000---数据\001---源数据';
p2='E:\008---Paper\003---Data\COSMIC\004---计算地磁纬度\程序包';
addpath(p1);
addpath(p2);
load C1
load UT1

% 变量赋值
T=UT1;
lon=C1(:,1);
lat=C1(:,2);
height=ones(length(lon),1)*350;

% 地磁纬度
temp=xcframe(T(:,1:6),[lat,lon,height], [], [], 'GEO', 'MAG', 'geod84', 'sph' );
D1=temp(:,1:2);

% 修正地磁纬度
[~,~,D,I]=igrfmagm(height,lat,lon,decyear(T(:,1:6)),13);
D1(:,3)=rad2deg(atan(deg2rad(I)./sqrt(cosd(lat))));

% 保存数据
save D1 D1

