clear;clc;

% 导入数据
T=repmat([2020,05,11,0,0,0],[73,1]);
lon=(-180:5:180)';
lat=(-90:2.5:90)';
height=ones(numel(lon),1)*350;

% 地磁纬度
temp=xcframe(T,[lat,lon,height], [], [], 'GEO', 'MAG', 'geod84', 'sph' );
mlat=temp(:,2);

% 修正地磁纬度
[~,~,D,I]=igrfmagm(height,lat,lon,decyear(T),13);
dip=rad2deg(atan(deg2rad(I)./sqrt(cosd(lat))));

