function xcframeDemo
% xcframeDemo
%
% This is demo shows how the xcframe function can be used to display satellite
% orbit data in different coordinate frames. The first plot is a 3D plot of the
% orbit data in the GEI frame, here the line color indicate the reltive speed of
% the satellite (blue is slower, red is faster). The next two plots are the
% satellites orbit in the GEO coordinate frame, that can be used to plot the
% satellites "ground path". Here the line colors indicate the relative speed and
% altitude of the satellite, respectively.

% Find path to this program
fHandle = @xcframeDemo;
tmp     = functions(fHandle);
progDir = fileparts(tmp.file);

% Load demo data
load(fullfile(progDir, 'xcframeDemoData.mat'))
% The "orbitData" in the file is the output from SGP4 algorithm, column 1 is
% time in Julian days, column 3 - 4 is position [km] and column 5 - 7 is
% velocity [km/s] in the TEME coordinate frame.

% Calculate the speed [km/s] and do a 3D plot of the orbit
speed = sqrt(orbitData(:, 5).^2 + orbitData(:, 6).^2 + orbitData(:, 7).^2);
% Note that the position in this call should be in [m]
plotOrbit3d(orbitData(:, 2:4)*1e3, speed, objName, [-50, -40], 2)

% Convert the data from TEME to the GEO coordinate frame in geodetic
% coordinates. TEME is not strictly the same as the ECI coordinate frame, but
% works as a very good estimate...
% Here we need to convert Julian days to a date matrix
time    = datevec(datetime(orbitData(:, 1), 'ConvertFrom', 'juliandate'));
% In this call use meters!
[geodPos, geodVel] = xcframe(time, orbitData(:, 2:4)*1e3, ...
  orbitData(:, 5:7)*1e3, [], 'GEI', 'GEO', 'cart', 'geod72');

% Calculate the speed [km/s] and do a plot of the "ground path"
speed = sqrt((geodVel(:, 1)*1e-3).^2 + (geodVel(:, 2)*1e-3).^2 + ...
 (geodVel(:, 3)*1e-3).^2);
plotGroundPath(geodPos, speed        , [objName, ' (Speed)'])
plotGroundPath(geodPos, geodVel(:, 3), [objName, ' (Altitude)'])

end



function plotOrbit3d(orbit, speed, titleStr, viewPt, zoomLev)

% Spherical earth
erad = 6371008.7714; % equatorial radius (meters)
prad = 6371008.7714; % polar radius (meters)

% Create figure
fp = figure('Color', 'k');
fp.InvertHardcopy = 'off';
hold on

% Turn off the normal axes
set(gca, 'NextPlot', 'add', 'Visible','off');
axis equal
axis auto

% Set initial view
view(viewPt);
axis vis3d

% Create wireframe globe using the ellipsoid function
[x, y, z] = ellipsoid(0, 0, 0, erad, erad, prad, 36);
surf(x, y, -z, 'FaceColor', 'b', 'EdgeColor', 'k');

% Plot the orbit
nCol      = 256;
colMap   = jet(nCol);
maxSpeed = max(speed);
minSpeed = min(speed);
for i = 1 : size(orbit, 1)-1
  colInd = floor((speed(i) - minSpeed)/(maxSpeed - minSpeed)*(nCol - 1)) + 1;
  line([orbit(i, 1), orbit(i+1, 1)], [orbit(i, 2), orbit(i+1, 2)], ...
    [orbit(i, 3), orbit(i+1, 3)], 'linewidth', 1.5, ...
    'color', colMap(colInd, :))
end
axis tight
camzoom(zoomLev)

% Make an axes to put the title in
ax1 = gca;
axes('Position', [0 0 1 1], 'Visible', 'off');
text(0.5, 0.95, titleStr, 'Color', 'White', 'FontSize', 16, ...
  'FontWeight', 'bold', 'HorizontalAlignment', 'center')
axes(ax1)
drawnow

end



function plotGroundPath(geodPos, zVal, titleStr)

% Find path to this program
fHandle = @plotGroundPath;
tmp     = functions(fHandle);
progDir = fileparts(tmp.file);

% Load a texture map
cData = imread(fullfile(progDir, 'earthtexture.jpg'));
cData = flipud(cData);

% Display the texture map
fp = figure;
fp.InvertHardcopy = 'off';
imagesc([-180, 180], [-90, 90], cData)
axis equal
axis tight
axis xy
xlabel('Longitude [deg]')
ylabel('Latitude [deg]')
title(titleStr)

% Find "breaks" in the orbit, not a foolproof way of doing it...
lng = geodPos(:, 2);
lat = geodPos(:, 1);
lngBreaks   = find(...
  (lng(1:end-1) >=  90 & lng(2:end) <= -90) | ...
  (lng(1:end-1) <= -90 & lng(2:end) >=  90));
latBreaks   = find(...
  (lat(1:end-1) >=  45 & lat(2:end) <= -45) | ...
  (lat(1:end-1) <= -45 & lat(2:end) >=  45));
orbitBreaks = unique([lngBreaks(:); latBreaks(:)]);

% Plot the orbit
nCol   = 256;
colMap = jet(nCol);
zMax   = max(zVal);
zMin   = min(zVal);
for i = 1 : length(lng)-1
  if (ismember(i, orbitBreaks)), continue, end
  colInd = floor((zVal(i) - zMin)/(zMax - zMin)*(nCol - 1)) + 1;
  line([lng(i), lng(i+1)], [lat(i), lat(i+1)], 'linewidth', 1.5, ...
    'color', colMap(colInd, :))
end
drawnow

end